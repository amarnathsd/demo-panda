 <!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <link rel="icon" href="/LogoIconColoured.png" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="theme-color" content="#000000" />
    <meta
      name="description"
      content="Our mission is to make visa processes as seamless as possible, offering personalized solutions that cater to the unique needs of each traveler. We strive to reduce the stress and uncertainty that often accompany visa applications, allowing our clients to focus on what truly matters—their travel plans and experiences. By continuously improving our processes and adopting new technologies, we aim to set new standards in visa facilitation services."
    />
    <link rel="apple-touch-icon" href="/LogoIconColoured.png" />
 
    <link rel="manifest" href="/manifest.json" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      rel="preload"
      as="style"
      href="https://fonts.googleapis.com/css2?family=Albert+Sans:wght@400;700;800&display=swap"
    />
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css2?family=Albert+Sans:wght@400;700;800&display=swap"
      media="print"
      onload="this.media='all'"
    />
    <noscript>
      <link
        rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Albert+Sans:wght@400;700;800&display=swap"
      />
    </noscript>
    <script data-noptimize="1" data-cfasync="false" data-wpfc-render="false">
  (function () {
      var script = document.createElement("script");
      script.async = 1;
      script.src = 'https://emrldco.com/NTA4NTMy.js?t=508532';
      document.head.appendChild(script);
  })();
</script>
    <script type="text/javascript">
      function load_clarity() {
        (function (c, l, a, r, i, t, y) {
          c[a] =
            c[a] ||
            function () {
              (c[a].q = c[a].q || []).push(arguments);
            };
          t = l.createElement(r);
          t.async = 1;
          t.src = "https://www.clarity.ms/tag/" + i;
          y = l.getElementsByTagName(r)[0];
          y.parentNode.insertBefore(t, y);
        })(window, document, "clarity", "script", "olh9546boc");
      }

      if ("requestIdleCallback" in window) {
        window.requestIdleCallback(load_clarity);
      } else {
        window.addEventListener("load", load_clarity);
      }
    </script>
    <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-LTDJMX2G36"></script>
<script>
  function load_gtag() {
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', 'G-LTDJMX2G36');
  }
  if (window.requestIdleCallback) {
    window.requestIdleCallback(load_gtag);
  } else {
    window.addEventListener('load', load_gtag);
  }
</script>

    <!-- TrustBox script -->
    <script
      type="text/javascript"
      src="//widget.trustpilot.com/bootstrap/v5/tp.widget.bootstrap.min.js"
      async
    ></script>
    <!-- End TrustBox script -->
    <title>The Flying Panda</title>
    <script type="module" crossorigin src="/assets/index-ZavE6wyR.js"></script>
    <link rel="stylesheet" crossorigin href="/assets/index-z1Q0cgJg.css">
  </head>
  <body>
    <div id="root"></div>
  </body>
</html> 

